<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cargar config.php desde la misma carpeta
require_once __DIR__ . '/config.php';

$mensaje = '';

try {
    $db = getDBConnection();
    $mensaje = "Conexión OK a la base de datos: " . DB_NAME;
} catch (Exception $e) {
    $mensaje = "Error de conexión: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Prueba de conexión BD</title>

    <!-- Bootstrap opcional para que se vea mejor -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Prueba de conexión a la base de datos</h5>
                </div>
                <div class="card-body">
                    <p class="lead">
                        <?php echo htmlspecialchars($mensaje); ?>
                    </p>
                    <a href="../index.php" class="btn btn-outline-primary btn-sm">Volver al inicio</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>

